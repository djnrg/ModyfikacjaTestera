﻿namespace Tester_VFS169
{
    partial class FormACLoop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormACLoop));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.labelDATA = new System.Windows.Forms.Label();
            this.TBSuctionPressure = new System.Windows.Forms.TextBox();
            this.TBDischargePressure = new System.Windows.Forms.TextBox();
            this.TBAirIn = new System.Windows.Forms.TextBox();
            this.TBAirOut = new System.Windows.Forms.TextBox();
            this.TBConcenserOut = new System.Windows.Forms.TextBox();
            this.TBConcenserIn = new System.Windows.Forms.TextBox();
            this.TBEvapIn = new System.Windows.Forms.TextBox();
            this.TBEvapOut = new System.Windows.Forms.TextBox();
            this.TBCompressor = new System.Windows.Forms.TextBox();
            this.TBSuction = new System.Windows.Forms.TextBox();
            this.TBDischarge = new System.Windows.Forms.TextBox();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.checkTopA = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.splitContainer1.Panel1.Controls.Add(this.labelDATA);
            this.splitContainer1.Panel1.Controls.Add(this.TBSuctionPressure);
            this.splitContainer1.Panel1.Controls.Add(this.TBDischargePressure);
            this.splitContainer1.Panel1.Controls.Add(this.TBAirIn);
            this.splitContainer1.Panel1.Controls.Add(this.TBAirOut);
            this.splitContainer1.Panel1.Controls.Add(this.TBConcenserOut);
            this.splitContainer1.Panel1.Controls.Add(this.TBConcenserIn);
            this.splitContainer1.Panel1.Controls.Add(this.TBEvapIn);
            this.splitContainer1.Panel1.Controls.Add(this.TBEvapOut);
            this.splitContainer1.Panel1.Controls.Add(this.TBCompressor);
            this.splitContainer1.Panel1.Controls.Add(this.TBSuction);
            this.splitContainer1.Panel1.Controls.Add(this.TBDischarge);
            this.splitContainer1.Panel1.Controls.Add(this.pictureBox);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.checkTopA);
            this.splitContainer1.Panel2.Controls.Add(this.button2);
            this.splitContainer1.Panel2.Controls.Add(this.button1);
            this.splitContainer1.Size = new System.Drawing.Size(694, 592);
            this.splitContainer1.SplitterDistance = 570;
            this.splitContainer1.TabIndex = 0;
            // 
            // labelDATA
            // 
            this.labelDATA.AutoSize = true;
            this.labelDATA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelDATA.Location = new System.Drawing.Point(12, 560);
            this.labelDATA.Name = "labelDATA";
            this.labelDATA.Size = new System.Drawing.Size(37, 16);
            this.labelDATA.TabIndex = 12;
            this.labelDATA.Text = "Data";
            // 
            // TBSuctionPressure
            // 
            this.TBSuctionPressure.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.TBSuctionPressure.Enabled = false;
            this.TBSuctionPressure.Location = new System.Drawing.Point(28, 282);
            this.TBSuctionPressure.Name = "TBSuctionPressure";
            this.TBSuctionPressure.Size = new System.Drawing.Size(60, 20);
            this.TBSuctionPressure.TabIndex = 11;
            this.TBSuctionPressure.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TBDischargePressure
            // 
            this.TBDischargePressure.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.TBDischargePressure.Enabled = false;
            this.TBDischargePressure.Location = new System.Drawing.Point(339, 264);
            this.TBDischargePressure.Name = "TBDischargePressure";
            this.TBDischargePressure.Size = new System.Drawing.Size(60, 20);
            this.TBDischargePressure.TabIndex = 10;
            this.TBDischargePressure.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TBAirIn
            // 
            this.TBAirIn.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.TBAirIn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TBAirIn.Enabled = false;
            this.TBAirIn.Location = new System.Drawing.Point(409, 129);
            this.TBAirIn.Name = "TBAirIn";
            this.TBAirIn.Size = new System.Drawing.Size(60, 20);
            this.TBAirIn.TabIndex = 9;
            this.TBAirIn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TBAirOut
            // 
            this.TBAirOut.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.TBAirOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TBAirOut.Enabled = false;
            this.TBAirOut.Location = new System.Drawing.Point(409, 44);
            this.TBAirOut.Name = "TBAirOut";
            this.TBAirOut.Size = new System.Drawing.Size(60, 20);
            this.TBAirOut.TabIndex = 8;
            this.TBAirOut.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TBConcenserOut
            // 
            this.TBConcenserOut.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.TBConcenserOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TBConcenserOut.Enabled = false;
            this.TBConcenserOut.Location = new System.Drawing.Point(311, 550);
            this.TBConcenserOut.Name = "TBConcenserOut";
            this.TBConcenserOut.Size = new System.Drawing.Size(60, 20);
            this.TBConcenserOut.TabIndex = 7;
            this.TBConcenserOut.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TBConcenserIn
            // 
            this.TBConcenserIn.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.TBConcenserIn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TBConcenserIn.Enabled = false;
            this.TBConcenserIn.Location = new System.Drawing.Point(311, 417);
            this.TBConcenserIn.Name = "TBConcenserIn";
            this.TBConcenserIn.Size = new System.Drawing.Size(60, 20);
            this.TBConcenserIn.TabIndex = 6;
            this.TBConcenserIn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TBEvapIn
            // 
            this.TBEvapIn.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.TBEvapIn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TBEvapIn.Enabled = false;
            this.TBEvapIn.Location = new System.Drawing.Point(205, 156);
            this.TBEvapIn.Name = "TBEvapIn";
            this.TBEvapIn.Size = new System.Drawing.Size(60, 20);
            this.TBEvapIn.TabIndex = 5;
            this.TBEvapIn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TBEvapOut
            // 
            this.TBEvapOut.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.TBEvapOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TBEvapOut.Enabled = false;
            this.TBEvapOut.Location = new System.Drawing.Point(219, 24);
            this.TBEvapOut.Name = "TBEvapOut";
            this.TBEvapOut.Size = new System.Drawing.Size(60, 20);
            this.TBEvapOut.TabIndex = 4;
            this.TBEvapOut.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TBCompressor
            // 
            this.TBCompressor.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.TBCompressor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TBCompressor.Enabled = false;
            this.TBCompressor.Location = new System.Drawing.Point(176, 340);
            this.TBCompressor.Name = "TBCompressor";
            this.TBCompressor.Size = new System.Drawing.Size(60, 20);
            this.TBCompressor.TabIndex = 3;
            this.TBCompressor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TBSuction
            // 
            this.TBSuction.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.TBSuction.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TBSuction.Enabled = false;
            this.TBSuction.Location = new System.Drawing.Point(113, 264);
            this.TBSuction.Name = "TBSuction";
            this.TBSuction.Size = new System.Drawing.Size(60, 20);
            this.TBSuction.TabIndex = 2;
            this.TBSuction.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TBDischarge
            // 
            this.TBDischarge.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.TBDischarge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TBDischarge.Enabled = false;
            this.TBDischarge.Location = new System.Drawing.Point(263, 264);
            this.TBDischarge.Name = "TBDischarge";
            this.TBDischarge.Size = new System.Drawing.Size(60, 20);
            this.TBDischarge.TabIndex = 1;
            this.TBDischarge.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox
            // 
            this.pictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox.Image = global::Tester_VFS169.Properties.Resources.AC_Loop;
            this.pictureBox.Location = new System.Drawing.Point(0, 0);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(570, 592);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox.TabIndex = 0;
            this.pictureBox.TabStop = false;
            // 
            // checkTopA
            // 
            this.checkTopA.AutoSize = true;
            this.checkTopA.Location = new System.Drawing.Point(19, 571);
            this.checkTopA.Name = "checkTopA";
            this.checkTopA.Size = new System.Drawing.Size(80, 17);
            this.checkTopA.TabIndex = 26;
            this.checkTopA.Text = "Stay on top";
            this.checkTopA.UseVisualStyleBackColor = true;
            this.checkTopA.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(9, 487);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 28);
            this.button2.TabIndex = 25;
            this.button2.Text = "Print graph";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(9, 524);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 40);
            this.button1.TabIndex = 3;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormACLoop
            // 
            this.AcceptButton = this.button1;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(694, 592);
            this.Controls.Add(this.splitContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(700, 620);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(700, 620);
            this.Name = "FormACLoop";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "AC Loop";
            this.Load += new System.EventHandler(this.FormACLoop_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.TextBox TBDischarge;
        private System.Windows.Forms.TextBox TBAirIn;
        private System.Windows.Forms.TextBox TBAirOut;
        private System.Windows.Forms.TextBox TBConcenserOut;
        private System.Windows.Forms.TextBox TBConcenserIn;
        private System.Windows.Forms.TextBox TBEvapIn;
        private System.Windows.Forms.TextBox TBCompressor;
        private System.Windows.Forms.TextBox TBSuction;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox TBSuctionPressure;
        private System.Windows.Forms.TextBox TBDischargePressure;
        private System.Windows.Forms.Label labelDATA;
        private System.Windows.Forms.CheckBox checkTopA;
        private System.Windows.Forms.TextBox TBEvapOut;
    }
}
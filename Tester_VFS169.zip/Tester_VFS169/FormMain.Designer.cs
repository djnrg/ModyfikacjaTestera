﻿namespace Tester_VFS169
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.menuMain = new System.Windows.Forms.MenuStrip();
            this.programSetupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.StripCOM = new System.Windows.Forms.ToolStripComboBox();
            this.StripBaud = new System.Windows.Forms.ToolStripComboBox();
            this.StripConnect = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.setupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.testDescriptioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startNewTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.continueTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.commentsToTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveTestStatusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.finishTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testParametersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.temperaturesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.pIDParametersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.graphsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aCLoopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pressuresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.temperatureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splashScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.StripStatusCOM = new System.Windows.Forms.ToolStripStatusLabel();
            this.StripProgressCOM = new System.Windows.Forms.ToolStripProgressBar();
            this.StripStatusData = new System.Windows.Forms.ToolStripStatusLabel();
            this.StripStatusDane = new System.Windows.Forms.ToolStripStatusLabel();
            this.COM = new System.IO.Ports.SerialPort(this.components);
            this.timerCOM = new System.Windows.Forms.Timer(this.components);
            this.timerStoper = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ledStoper = new NationalInstruments.UI.WindowsForms.Led();
            this.buttonReset = new System.Windows.Forms.Button();
            this.buttonStart = new System.Windows.Forms.Button();
            this.labelStoper = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.gaugeDischargeLAB = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.thermometerDischargeTB = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.thermometerDischarge = new NationalInstruments.UI.WindowsForms.Thermometer();
            this.gaugeDischarge = new NationalInstruments.UI.WindowsForms.Gauge();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.gaugeSuctionLAB = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.thermometerSuctionTB = new System.Windows.Forms.TextBox();
            this.thermometerSuction = new NationalInstruments.UI.WindowsForms.Thermometer();
            this.gaugeSuction = new NationalInstruments.UI.WindowsForms.Gauge();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.thermometerCondOutTB = new System.Windows.Forms.TextBox();
            this.thermometerCondInTB = new System.Windows.Forms.TextBox();
            this.thermometerCondOut = new NationalInstruments.UI.WindowsForms.Thermometer();
            this.thermometerCondIn = new NationalInstruments.UI.WindowsForms.Thermometer();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.HumidityAirOutTB = new System.Windows.Forms.TextBox();
            this.HumidityAirInTB = new System.Windows.Forms.TextBox();
            this.thermometerAirOutTB = new System.Windows.Forms.TextBox();
            this.thermometerAirInTB = new System.Windows.Forms.TextBox();
            this.thermometerEvapOutTB = new System.Windows.Forms.TextBox();
            this.thermometerEvapInTB = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.ledCoil = new NationalInstruments.UI.WindowsForms.Led();
            this.textBoxCoilCycles = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.meterCoilCurrent = new NationalInstruments.UI.WindowsForms.Meter();
            this.meterCoilVoltage = new NationalInstruments.UI.WindowsForms.Meter();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBoxECVcurrent = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBoxECVvoltage = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.slide1 = new NationalInstruments.UI.WindowsForms.Slide();
            this.meterRPM = new NationalInstruments.UI.WindowsForms.Meter();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.thermometerCompressorTB = new System.Windows.Forms.TextBox();
            this.textBoxCompressorLimit = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.ledCompressor = new NationalInstruments.UI.WindowsForms.Led();
            this.thermometerCompressor = new NationalInstruments.UI.WindowsForms.Thermometer();
            this.thermometerHotbox = new NationalInstruments.UI.WindowsForms.Thermometer();
            this.ledHotbox = new NationalInstruments.UI.WindowsForms.Led();
            this.textBoxHBmax = new System.Windows.Forms.TextBox();
            this.textBoxHBmin = new System.Windows.Forms.TextBox();
            this.thermometerHotboxTB = new System.Windows.Forms.TextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.buttonDisconnect = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.menuMain.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ledStoper)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.thermometerDischarge)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gaugeDischarge)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.thermometerSuction)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gaugeSuction)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.thermometerCondOut)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thermometerCondIn)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ledCoil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.meterCoilCurrent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.meterCoilVoltage)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.slide1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.meterRPM)).BeginInit();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ledCompressor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thermometerCompressor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thermometerHotbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ledHotbox)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuMain
            // 
            this.menuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.programSetupToolStripMenuItem,
            this.testDescriptioToolStripMenuItem,
            this.testParametersToolStripMenuItem,
            this.graphsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuMain.Location = new System.Drawing.Point(0, 0);
            this.menuMain.Name = "menuMain";
            this.menuMain.Size = new System.Drawing.Size(1390, 24);
            this.menuMain.TabIndex = 0;
            this.menuMain.Text = "menuStrip1";
            // 
            // programSetupToolStripMenuItem
            // 
            this.programSetupToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem,
            this.StripCOM,
            this.StripBaud,
            this.StripConnect,
            this.toolStripSeparator1,
            this.setupToolStripMenuItem,
            this.toolStripSeparator2,
            this.exitToolStripMenuItem1});
            this.programSetupToolStripMenuItem.Name = "programSetupToolStripMenuItem";
            this.programSetupToolStripMenuItem.Size = new System.Drawing.Size(97, 20);
            this.programSetupToolStripMenuItem.Text = "Program setup";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.exitToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.exitToolStripMenuItem.Text = "COM Port";
            // 
            // StripCOM
            // 
            this.StripCOM.Name = "StripCOM";
            this.StripCOM.Size = new System.Drawing.Size(121, 23);
            // 
            // StripBaud
            // 
            this.StripBaud.Items.AddRange(new object[] {
            "9600",
            "19200",
            "115200"});
            this.StripBaud.Name = "StripBaud";
            this.StripBaud.Size = new System.Drawing.Size(121, 23);
            // 
            // StripConnect
            // 
            this.StripConnect.Enabled = false;
            this.StripConnect.Name = "StripConnect";
            this.StripConnect.Size = new System.Drawing.Size(181, 22);
            this.StripConnect.Text = "Connect!!!";
            this.StripConnect.Click += new System.EventHandler(this.StripConnect_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(178, 6);
            // 
            // setupToolStripMenuItem
            // 
            this.setupToolStripMenuItem.Name = "setupToolStripMenuItem";
            this.setupToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.setupToolStripMenuItem.Text = "Setup general";
            this.setupToolStripMenuItem.Click += new System.EventHandler(this.setupToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(178, 6);
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(181, 22);
            this.exitToolStripMenuItem1.Text = "Exit";
            this.exitToolStripMenuItem1.Click += new System.EventHandler(this.exitToolStripMenuItem1_Click);
            // 
            // testDescriptioToolStripMenuItem
            // 
            this.testDescriptioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.startNewTestToolStripMenuItem,
            this.continueTestToolStripMenuItem,
            this.toolStripSeparator3,
            this.commentsToTestToolStripMenuItem,
            this.saveTestStatusToolStripMenuItem,
            this.toolStripSeparator4,
            this.finishTestToolStripMenuItem});
            this.testDescriptioToolStripMenuItem.Name = "testDescriptioToolStripMenuItem";
            this.testDescriptioToolStripMenuItem.Size = new System.Drawing.Size(103, 20);
            this.testDescriptioToolStripMenuItem.Text = "Test description";
            // 
            // startNewTestToolStripMenuItem
            // 
            this.startNewTestToolStripMenuItem.Name = "startNewTestToolStripMenuItem";
            this.startNewTestToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.startNewTestToolStripMenuItem.Text = "Start new test";
            // 
            // continueTestToolStripMenuItem
            // 
            this.continueTestToolStripMenuItem.Name = "continueTestToolStripMenuItem";
            this.continueTestToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.continueTestToolStripMenuItem.Text = "Continue test";
            this.continueTestToolStripMenuItem.Click += new System.EventHandler(this.continueTestToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(166, 6);
            // 
            // commentsToTestToolStripMenuItem
            // 
            this.commentsToTestToolStripMenuItem.Enabled = false;
            this.commentsToTestToolStripMenuItem.Name = "commentsToTestToolStripMenuItem";
            this.commentsToTestToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.commentsToTestToolStripMenuItem.Text = "Comments to test";
            // 
            // saveTestStatusToolStripMenuItem
            // 
            this.saveTestStatusToolStripMenuItem.Enabled = false;
            this.saveTestStatusToolStripMenuItem.Name = "saveTestStatusToolStripMenuItem";
            this.saveTestStatusToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.saveTestStatusToolStripMenuItem.Text = "Save test status";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(166, 6);
            // 
            // finishTestToolStripMenuItem
            // 
            this.finishTestToolStripMenuItem.Enabled = false;
            this.finishTestToolStripMenuItem.Name = "finishTestToolStripMenuItem";
            this.finishTestToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.finishTestToolStripMenuItem.Text = "Finish test";
            // 
            // testParametersToolStripMenuItem
            // 
            this.testParametersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.temperaturesToolStripMenuItem,
            this.toolStripSeparator6,
            this.pIDParametersToolStripMenuItem});
            this.testParametersToolStripMenuItem.Name = "testParametersToolStripMenuItem";
            this.testParametersToolStripMenuItem.Size = new System.Drawing.Size(103, 20);
            this.testParametersToolStripMenuItem.Text = "Test parameters";
            // 
            // temperaturesToolStripMenuItem
            // 
            this.temperaturesToolStripMenuItem.Name = "temperaturesToolStripMenuItem";
            this.temperaturesToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.temperaturesToolStripMenuItem.Text = "Setup point";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(151, 6);
            // 
            // pIDParametersToolStripMenuItem
            // 
            this.pIDParametersToolStripMenuItem.Enabled = false;
            this.pIDParametersToolStripMenuItem.Name = "pIDParametersToolStripMenuItem";
            this.pIDParametersToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.pIDParametersToolStripMenuItem.Text = "PID parameters";
            // 
            // graphsToolStripMenuItem
            // 
            this.graphsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aCLoopToolStripMenuItem,
            this.pressuresToolStripMenuItem,
            this.temperatureToolStripMenuItem});
            this.graphsToolStripMenuItem.Name = "graphsToolStripMenuItem";
            this.graphsToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.graphsToolStripMenuItem.Text = "Graphs";
            // 
            // aCLoopToolStripMenuItem
            // 
            this.aCLoopToolStripMenuItem.Name = "aCLoopToolStripMenuItem";
            this.aCLoopToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.aCLoopToolStripMenuItem.Text = "A/C Loop";
            this.aCLoopToolStripMenuItem.Click += new System.EventHandler(this.aCLoopToolStripMenuItem_Click);
            // 
            // pressuresToolStripMenuItem
            // 
            this.pressuresToolStripMenuItem.Name = "pressuresToolStripMenuItem";
            this.pressuresToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.pressuresToolStripMenuItem.Text = "Pressures";
            this.pressuresToolStripMenuItem.Click += new System.EventHandler(this.pressuresToolStripMenuItem_Click);
            // 
            // temperatureToolStripMenuItem
            // 
            this.temperatureToolStripMenuItem.Name = "temperatureToolStripMenuItem";
            this.temperatureToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.temperatureToolStripMenuItem.Text = "Temperature";
            this.temperatureToolStripMenuItem.Click += new System.EventHandler(this.temperatureToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem1,
            this.toolStripSeparator5,
            this.aboutToolStripMenuItem,
            this.splashScreenToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // helpToolStripMenuItem1
            // 
            this.helpToolStripMenuItem1.Name = "helpToolStripMenuItem1";
            this.helpToolStripMenuItem1.Size = new System.Drawing.Size(146, 22);
            this.helpToolStripMenuItem1.Text = "Help";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(143, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // splashScreenToolStripMenuItem
            // 
            this.splashScreenToolStripMenuItem.Name = "splashScreenToolStripMenuItem";
            this.splashScreenToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.splashScreenToolStripMenuItem.Text = "Splash Screen";
            this.splashScreenToolStripMenuItem.Click += new System.EventHandler(this.splashScreenToolStripMenuItem_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StripStatusCOM,
            this.StripProgressCOM,
            this.StripStatusData,
            this.StripStatusDane});
            this.statusStrip.Location = new System.Drawing.Point(0, 746);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1390, 22);
            this.statusStrip.TabIndex = 1;
            this.statusStrip.Text = "statusStrip1";
            // 
            // StripStatusCOM
            // 
            this.StripStatusCOM.Name = "StripStatusCOM";
            this.StripStatusCOM.Size = new System.Drawing.Size(106, 17);
            this.StripStatusCOM.Text = "COM Port active:   ";
            // 
            // StripProgressCOM
            // 
            this.StripProgressCOM.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.StripProgressCOM.Name = "StripProgressCOM";
            this.StripProgressCOM.Size = new System.Drawing.Size(30, 16);
            // 
            // StripStatusData
            // 
            this.StripStatusData.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.StripStatusData.Name = "StripStatusData";
            this.StripStatusData.Size = new System.Drawing.Size(0, 17);
            // 
            // StripStatusDane
            // 
            this.StripStatusDane.Name = "StripStatusDane";
            this.StripStatusDane.Size = new System.Drawing.Size(49, 17);
            this.StripStatusDane.Text = "Dane???";
            // 
            // COM
            // 
            this.COM.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.COM_DataReceived);
            // 
            // timerCOM
            // 
            this.timerCOM.Enabled = true;
            this.timerCOM.Interval = 1000;
            this.timerCOM.Tick += new System.EventHandler(this.timerCOM_Tick);
            // 
            // timerStoper
            // 
            this.timerStoper.Tick += new System.EventHandler(this.timerStoper_Tick);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.groupBox1.Controls.Add(this.ledStoper);
            this.groupBox1.Controls.Add(this.buttonReset);
            this.groupBox1.Controls.Add(this.buttonStart);
            this.groupBox1.Controls.Add(this.labelStoper);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox1.Location = new System.Drawing.Point(1015, 30);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 6, 6, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(359, 133);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Test time";
            // 
            // ledStoper
            // 
            this.ledStoper.LedStyle = NationalInstruments.UI.LedStyle.Round3D;
            this.ledStoper.Location = new System.Drawing.Point(285, 13);
            this.ledStoper.Name = "ledStoper";
            this.ledStoper.Size = new System.Drawing.Size(64, 64);
            this.ledStoper.TabIndex = 3;
            // 
            // buttonReset
            // 
            this.buttonReset.Location = new System.Drawing.Point(172, 86);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(100, 36);
            this.buttonReset.TabIndex = 2;
            this.buttonReset.Text = "Reset";
            this.buttonReset.UseVisualStyleBackColor = true;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(64, 86);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(100, 36);
            this.buttonStart.TabIndex = 1;
            this.buttonStart.Text = "Start";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // labelStoper
            // 
            this.labelStoper.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelStoper.AutoSize = true;
            this.labelStoper.Font = new System.Drawing.Font("Arial", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelStoper.Location = new System.Drawing.Point(84, 27);
            this.labelStoper.Name = "labelStoper";
            this.labelStoper.Size = new System.Drawing.Size(174, 40);
            this.labelStoper.TabIndex = 0;
            this.labelStoper.Text = "000:00:00";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.gaugeDischargeLAB);
            this.groupBox2.Controls.Add(this.textBox7);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.thermometerDischargeTB);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.thermometerDischarge);
            this.groupBox2.Controls.Add(this.gaugeDischarge);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox2.Location = new System.Drawing.Point(9, 27);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(480, 400);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Discharge";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label28.Location = new System.Drawing.Point(422, 334);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(47, 20);
            this.label28.TabIndex = 7;
            this.label28.Text = "degC";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label26.Location = new System.Drawing.Point(243, 355);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(47, 20);
            this.label26.TabIndex = 7;
            this.label26.Text = "BarG";
            // 
            // gaugeDischargeLAB
            // 
            this.gaugeDischargeLAB.AutoSize = true;
            this.gaugeDischargeLAB.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.gaugeDischargeLAB.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.gaugeDischargeLAB.Location = new System.Drawing.Point(148, 257);
            this.gaugeDischargeLAB.Name = "gaugeDischargeLAB";
            this.gaugeDischargeLAB.Size = new System.Drawing.Size(71, 25);
            this.gaugeDischargeLAB.TabIndex = 6;
            this.gaugeDischargeLAB.Text = "00,00";
            this.gaugeDischargeLAB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.Window;
            this.textBox7.Location = new System.Drawing.Point(137, 348);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 26);
            this.textBox7.TabIndex = 5;
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 351);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 20);
            this.label7.TabIndex = 4;
            this.label7.Text = "Setup point";
            // 
            // thermometerDischargeTB
            // 
            this.thermometerDischargeTB.BackColor = System.Drawing.SystemColors.MenuBar;
            this.thermometerDischargeTB.Location = new System.Drawing.Point(336, 331);
            this.thermometerDischargeTB.Name = "thermometerDischargeTB";
            this.thermometerDischargeTB.ReadOnly = true;
            this.thermometerDischargeTB.Size = new System.Drawing.Size(80, 26);
            this.thermometerDischargeTB.TabIndex = 3;
            this.thermometerDischargeTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(162, 282);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 16);
            this.label5.TabIndex = 2;
            this.label5.Text = "BarG";
            // 
            // thermometerDischarge
            // 
            this.thermometerDischarge.Location = new System.Drawing.Point(329, 25);
            this.thermometerDischarge.Name = "thermometerDischarge";
            this.thermometerDischarge.Range = new NationalInstruments.UI.Range(0D, 125D);
            this.thermometerDischarge.Size = new System.Drawing.Size(151, 300);
            this.thermometerDischarge.TabIndex = 1;
            // 
            // gaugeDischarge
            // 
            this.gaugeDischarge.DialColor = System.Drawing.SystemColors.ButtonFace;
            this.gaugeDischarge.Location = new System.Drawing.Point(33, 25);
            this.gaugeDischarge.Name = "gaugeDischarge";
            this.gaugeDischarge.Range = new NationalInstruments.UI.Range(0D, 30D);
            this.gaugeDischarge.ScaleArc = new NationalInstruments.UI.Arc(230F, -280F);
            this.gaugeDischarge.Size = new System.Drawing.Size(300, 300);
            this.gaugeDischarge.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.gaugeSuctionLAB);
            this.groupBox3.Controls.Add(this.textBox10);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.thermometerSuctionTB);
            this.groupBox3.Controls.Add(this.thermometerSuction);
            this.groupBox3.Controls.Add(this.gaugeSuction);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox3.Location = new System.Drawing.Point(513, 27);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(480, 400);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Suction";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label29.Location = new System.Drawing.Point(424, 331);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(47, 20);
            this.label29.TabIndex = 8;
            this.label29.Text = "degC";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label27.Location = new System.Drawing.Point(229, 354);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(47, 20);
            this.label27.TabIndex = 7;
            this.label27.Text = "BarG";
            // 
            // gaugeSuctionLAB
            // 
            this.gaugeSuctionLAB.AutoSize = true;
            this.gaugeSuctionLAB.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.gaugeSuctionLAB.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.gaugeSuctionLAB.Location = new System.Drawing.Point(161, 257);
            this.gaugeSuctionLAB.Name = "gaugeSuctionLAB";
            this.gaugeSuctionLAB.Size = new System.Drawing.Size(58, 25);
            this.gaugeSuctionLAB.TabIndex = 6;
            this.gaugeSuctionLAB.Text = "0,00";
            this.gaugeSuctionLAB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.SystemColors.Window;
            this.textBox10.Location = new System.Drawing.Point(123, 348);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 26);
            this.textBox10.TabIndex = 5;
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 351);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 20);
            this.label11.TabIndex = 4;
            this.label11.Text = "Setup point";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(170, 282);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 16);
            this.label6.TabIndex = 3;
            this.label6.Text = "BarG";
            // 
            // thermometerSuctionTB
            // 
            this.thermometerSuctionTB.BackColor = System.Drawing.SystemColors.MenuBar;
            this.thermometerSuctionTB.Location = new System.Drawing.Point(340, 328);
            this.thermometerSuctionTB.Name = "thermometerSuctionTB";
            this.thermometerSuctionTB.ReadOnly = true;
            this.thermometerSuctionTB.Size = new System.Drawing.Size(80, 26);
            this.thermometerSuctionTB.TabIndex = 2;
            this.thermometerSuctionTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // thermometerSuction
            // 
            this.thermometerSuction.Location = new System.Drawing.Point(324, 30);
            this.thermometerSuction.Name = "thermometerSuction";
            this.thermometerSuction.Range = new NationalInstruments.UI.Range(0D, 50D);
            this.thermometerSuction.Size = new System.Drawing.Size(150, 300);
            this.thermometerSuction.TabIndex = 1;
            // 
            // gaugeSuction
            // 
            this.gaugeSuction.DialColor = System.Drawing.SystemColors.ButtonFace;
            this.gaugeSuction.Location = new System.Drawing.Point(32, 25);
            this.gaugeSuction.Name = "gaugeSuction";
            this.gaugeSuction.Range = new NationalInstruments.UI.Range(0D, 12D);
            this.gaugeSuction.ScaleArc = new NationalInstruments.UI.Arc(230F, -280F);
            this.gaugeSuction.Size = new System.Drawing.Size(300, 300);
            this.gaugeSuction.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.groupBox4.Controls.Add(this.label30);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.thermometerCondOutTB);
            this.groupBox4.Controls.Add(this.thermometerCondInTB);
            this.groupBox4.Controls.Add(this.thermometerCondOut);
            this.groupBox4.Controls.Add(this.thermometerCondIn);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox4.Location = new System.Drawing.Point(9, 428);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(293, 200);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Condenser";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(135, 122);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(45, 16);
            this.label30.TabIndex = 7;
            this.label30.Text = "degC";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(134, 27);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(45, 16);
            this.label25.TabIndex = 6;
            this.label25.Text = "degC";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "IN";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "OUT";
            // 
            // thermometerCondOutTB
            // 
            this.thermometerCondOutTB.BackColor = System.Drawing.SystemColors.MenuBar;
            this.thermometerCondOutTB.Location = new System.Drawing.Point(46, 118);
            this.thermometerCondOutTB.Name = "thermometerCondOutTB";
            this.thermometerCondOutTB.ReadOnly = true;
            this.thermometerCondOutTB.Size = new System.Drawing.Size(83, 22);
            this.thermometerCondOutTB.TabIndex = 5;
            this.thermometerCondOutTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // thermometerCondInTB
            // 
            this.thermometerCondInTB.BackColor = System.Drawing.SystemColors.MenuBar;
            this.thermometerCondInTB.Location = new System.Drawing.Point(46, 23);
            this.thermometerCondInTB.Name = "thermometerCondInTB";
            this.thermometerCondInTB.ReadOnly = true;
            this.thermometerCondInTB.Size = new System.Drawing.Size(83, 22);
            this.thermometerCondInTB.TabIndex = 4;
            this.thermometerCondInTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // thermometerCondOut
            // 
            this.thermometerCondOut.Location = new System.Drawing.Point(6, 113);
            this.thermometerCondOut.Name = "thermometerCondOut";
            this.thermometerCondOut.ScalePosition = NationalInstruments.UI.NumericScalePosition.Bottom;
            this.thermometerCondOut.Size = new System.Drawing.Size(285, 81);
            this.thermometerCondOut.TabIndex = 3;
            // 
            // thermometerCondIn
            // 
            this.thermometerCondIn.Location = new System.Drawing.Point(6, 21);
            this.thermometerCondIn.Name = "thermometerCondIn";
            this.thermometerCondIn.ScalePosition = NationalInstruments.UI.NumericScalePosition.Bottom;
            this.thermometerCondIn.Size = new System.Drawing.Size(285, 71);
            this.thermometerCondIn.TabIndex = 2;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.groupBox5.Controls.Add(this.label37);
            this.groupBox5.Controls.Add(this.label36);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.label34);
            this.groupBox5.Controls.Add(this.label33);
            this.groupBox5.Controls.Add(this.label32);
            this.groupBox5.Controls.Add(this.HumidityAirOutTB);
            this.groupBox5.Controls.Add(this.HumidityAirInTB);
            this.groupBox5.Controls.Add(this.thermometerAirOutTB);
            this.groupBox5.Controls.Add(this.thermometerAirInTB);
            this.groupBox5.Controls.Add(this.thermometerEvapOutTB);
            this.groupBox5.Controls.Add(this.thermometerEvapInTB);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox5.Location = new System.Drawing.Point(513, 428);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(286, 200);
            this.groupBox5.TabIndex = 8;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Evapurator";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(260, 168);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(21, 16);
            this.label36.TabIndex = 12;
            this.label36.Text = "%";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(145, 168);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(45, 16);
            this.label35.TabIndex = 12;
            this.label35.Text = "degC";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(147, 124);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(45, 16);
            this.label34.TabIndex = 11;
            this.label34.Text = "degC";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(222, 79);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(45, 16);
            this.label33.TabIndex = 10;
            this.label33.Text = "degC";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(222, 34);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(45, 16);
            this.label32.TabIndex = 9;
            this.label32.Text = "degC";
            // 
            // HumidityAirOutTB
            // 
            this.HumidityAirOutTB.BackColor = System.Drawing.SystemColors.MenuBar;
            this.HumidityAirOutTB.Location = new System.Drawing.Point(198, 165);
            this.HumidityAirOutTB.Name = "HumidityAirOutTB";
            this.HumidityAirOutTB.ReadOnly = true;
            this.HumidityAirOutTB.Size = new System.Drawing.Size(60, 22);
            this.HumidityAirOutTB.TabIndex = 9;
            this.HumidityAirOutTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // HumidityAirInTB
            // 
            this.HumidityAirInTB.BackColor = System.Drawing.SystemColors.MenuBar;
            this.HumidityAirInTB.Location = new System.Drawing.Point(198, 119);
            this.HumidityAirInTB.Name = "HumidityAirInTB";
            this.HumidityAirInTB.ReadOnly = true;
            this.HumidityAirInTB.Size = new System.Drawing.Size(60, 22);
            this.HumidityAirInTB.TabIndex = 8;
            this.HumidityAirInTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // thermometerAirOutTB
            // 
            this.thermometerAirOutTB.BackColor = System.Drawing.SystemColors.MenuBar;
            this.thermometerAirOutTB.Location = new System.Drawing.Point(75, 165);
            this.thermometerAirOutTB.Name = "thermometerAirOutTB";
            this.thermometerAirOutTB.ReadOnly = true;
            this.thermometerAirOutTB.Size = new System.Drawing.Size(70, 22);
            this.thermometerAirOutTB.TabIndex = 7;
            this.thermometerAirOutTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // thermometerAirInTB
            // 
            this.thermometerAirInTB.BackColor = System.Drawing.SystemColors.MenuBar;
            this.thermometerAirInTB.Location = new System.Drawing.Point(75, 119);
            this.thermometerAirInTB.Name = "thermometerAirInTB";
            this.thermometerAirInTB.ReadOnly = true;
            this.thermometerAirInTB.Size = new System.Drawing.Size(70, 22);
            this.thermometerAirInTB.TabIndex = 6;
            this.thermometerAirInTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // thermometerEvapOutTB
            // 
            this.thermometerEvapOutTB.BackColor = System.Drawing.SystemColors.MenuBar;
            this.thermometerEvapOutTB.Location = new System.Drawing.Point(140, 75);
            this.thermometerEvapOutTB.Name = "thermometerEvapOutTB";
            this.thermometerEvapOutTB.ReadOnly = true;
            this.thermometerEvapOutTB.Size = new System.Drawing.Size(80, 22);
            this.thermometerEvapOutTB.TabIndex = 5;
            this.thermometerEvapOutTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // thermometerEvapInTB
            // 
            this.thermometerEvapInTB.BackColor = System.Drawing.SystemColors.MenuBar;
            this.thermometerEvapInTB.Location = new System.Drawing.Point(140, 31);
            this.thermometerEvapInTB.Name = "thermometerEvapInTB";
            this.thermometerEvapInTB.ReadOnly = true;
            this.thermometerEvapInTB.Size = new System.Drawing.Size(80, 22);
            this.thermometerEvapInTB.TabIndex = 4;
            this.thermometerEvapInTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 171);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 16);
            this.label9.TabIndex = 3;
            this.label9.Text = "Air OUT";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 125);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 16);
            this.label8.TabIndex = 2;
            this.label8.Text = "Air IN";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "Evapurator OUT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Evapurator IN";
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.groupBox6.Controls.Add(this.ledCoil);
            this.groupBox6.Controls.Add(this.textBoxCoilCycles);
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Controls.Add(this.meterCoilCurrent);
            this.groupBox6.Controls.Add(this.meterCoilVoltage);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Controls.Add(this.label15);
            this.groupBox6.Controls.Add(this.label14);
            this.groupBox6.Controls.Add(this.textBox17);
            this.groupBox6.Controls.Add(this.textBox16);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox6.Location = new System.Drawing.Point(1015, 411);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(359, 327);
            this.groupBox6.TabIndex = 9;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Coil setup";
            // 
            // ledCoil
            // 
            this.ledCoil.LedStyle = NationalInstruments.UI.LedStyle.Round3D;
            this.ledCoil.Location = new System.Drawing.Point(312, 56);
            this.ledCoil.Name = "ledCoil";
            this.ledCoil.Size = new System.Drawing.Size(32, 32);
            this.ledCoil.TabIndex = 10;
            // 
            // textBoxCoilCycles
            // 
            this.textBoxCoilCycles.BackColor = System.Drawing.SystemColors.MenuBar;
            this.textBoxCoilCycles.Location = new System.Drawing.Point(132, 59);
            this.textBoxCoilCycles.Name = "textBoxCoilCycles";
            this.textBoxCoilCycles.ReadOnly = true;
            this.textBoxCoilCycles.Size = new System.Drawing.Size(167, 26);
            this.textBoxCoilCycles.TabIndex = 9;
            this.textBoxCoilCycles.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(24, 65);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(102, 20);
            this.label21.TabIndex = 8;
            this.label21.Text = "Cycles total";
            // 
            // meterCoilCurrent
            // 
            this.meterCoilCurrent.Border = NationalInstruments.UI.Border.Raised;
            this.meterCoilCurrent.Caption = "Coil current";
            this.meterCoilCurrent.CaptionBackColor = System.Drawing.SystemColors.AppWorkspace;
            this.meterCoilCurrent.CaptionPosition = NationalInstruments.UI.CaptionPosition.Right;
            this.meterCoilCurrent.DialColor = System.Drawing.SystemColors.AppWorkspace;
            this.meterCoilCurrent.Location = new System.Drawing.Point(179, 92);
            this.meterCoilCurrent.Name = "meterCoilCurrent";
            this.meterCoilCurrent.Range = new NationalInstruments.UI.Range(0D, 5D);
            this.meterCoilCurrent.ScaleArc = new NationalInstruments.UI.Arc(45F, -90F);
            this.meterCoilCurrent.Size = new System.Drawing.Size(174, 232);
            this.meterCoilCurrent.TabIndex = 7;
            // 
            // meterCoilVoltage
            // 
            this.meterCoilVoltage.Border = NationalInstruments.UI.Border.Raised;
            this.meterCoilVoltage.Caption = "Coil voltage";
            this.meterCoilVoltage.CaptionBackColor = System.Drawing.SystemColors.AppWorkspace;
            this.meterCoilVoltage.CaptionPosition = NationalInstruments.UI.CaptionPosition.Left;
            this.meterCoilVoltage.DialColor = System.Drawing.SystemColors.AppWorkspace;
            this.meterCoilVoltage.Location = new System.Drawing.Point(6, 92);
            this.meterCoilVoltage.Name = "meterCoilVoltage";
            this.meterCoilVoltage.Range = new NationalInstruments.UI.Range(0D, 24D);
            this.meterCoilVoltage.ScaleArc = new NationalInstruments.UI.Arc(225F, -90F);
            this.meterCoilVoltage.Size = new System.Drawing.Size(167, 232);
            this.meterCoilVoltage.TabIndex = 6;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(308, 28);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 20);
            this.label16.TabIndex = 5;
            this.label16.Text = "[sek]";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(149, 28);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 20);
            this.label15.TabIndex = 4;
            this.label15.Text = "OFF";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 28);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(34, 20);
            this.label14.TabIndex = 3;
            this.label14.Text = "ON";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(199, 25);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(100, 26);
            this.textBox17.TabIndex = 2;
            this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(44, 25);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 26);
            this.textBox16.TabIndex = 1;
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.groupBox7.Controls.Add(this.textBoxECVcurrent);
            this.groupBox7.Controls.Add(this.label20);
            this.groupBox7.Controls.Add(this.textBoxECVvoltage);
            this.groupBox7.Controls.Add(this.label13);
            this.groupBox7.Controls.Add(this.textBox21);
            this.groupBox7.Controls.Add(this.label19);
            this.groupBox7.Controls.Add(this.textBox20);
            this.groupBox7.Controls.Add(this.label18);
            this.groupBox7.Controls.Add(this.textBox19);
            this.groupBox7.Controls.Add(this.label17);
            this.groupBox7.Controls.Add(this.textBox18);
            this.groupBox7.Controls.Add(this.label10);
            this.groupBox7.Enabled = false;
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox7.Location = new System.Drawing.Point(513, 635);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(480, 98);
            this.groupBox7.TabIndex = 10;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "ECV";
            // 
            // textBoxECVcurrent
            // 
            this.textBoxECVcurrent.BackColor = System.Drawing.SystemColors.MenuBar;
            this.textBoxECVcurrent.Location = new System.Drawing.Point(380, 59);
            this.textBoxECVcurrent.Name = "textBoxECVcurrent";
            this.textBoxECVcurrent.ReadOnly = true;
            this.textBoxECVcurrent.Size = new System.Drawing.Size(85, 26);
            this.textBoxECVcurrent.TabIndex = 11;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(245, 64);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(135, 20);
            this.label20.TabIndex = 10;
            this.label20.Text = "ECV CURRENT";
            // 
            // textBoxECVvoltage
            // 
            this.textBoxECVvoltage.BackColor = System.Drawing.SystemColors.MenuBar;
            this.textBoxECVvoltage.Location = new System.Drawing.Point(152, 61);
            this.textBoxECVvoltage.Name = "textBoxECVvoltage";
            this.textBoxECVvoltage.ReadOnly = true;
            this.textBoxECVvoltage.Size = new System.Drawing.Size(71, 26);
            this.textBoxECVvoltage.TabIndex = 9;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(13, 65);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(133, 20);
            this.label13.TabIndex = 8;
            this.label13.Text = "ECV VOLTAGE";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(400, 22);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(65, 26);
            this.textBox21.TabIndex = 7;
            this.textBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(363, 25);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(34, 20);
            this.label19.TabIndex = 6;
            this.label19.Text = "DC";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(292, 22);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(65, 26);
            this.textBox20.TabIndex = 5;
            this.textBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(261, 25);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(31, 20);
            this.label18.TabIndex = 4;
            this.label18.Text = "Hz";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(174, 23);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(60, 26);
            this.textBox19.TabIndex = 3;
            this.textBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(128, 26);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 20);
            this.label17.TabIndex = 2;
            this.label17.Text = "OFF";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(50, 23);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(60, 26);
            this.textBox18.TabIndex = 1;
            this.textBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(34, 20);
            this.label10.TabIndex = 0;
            this.label10.Text = "ON";
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.groupBox8.Controls.Add(this.slide1);
            this.groupBox8.Controls.Add(this.meterRPM);
            this.groupBox8.Enabled = false;
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox8.Location = new System.Drawing.Point(1015, 166);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(359, 239);
            this.groupBox8.TabIndex = 11;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Engine speed";
            // 
            // slide1
            // 
            this.slide1.CoercionInterval = 10D;
            this.slide1.Location = new System.Drawing.Point(6, 188);
            this.slide1.Name = "slide1";
            this.slide1.Range = new NationalInstruments.UI.Range(0D, 6000D);
            this.slide1.ScalePosition = NationalInstruments.UI.NumericScalePosition.Bottom;
            this.slide1.Size = new System.Drawing.Size(347, 50);
            this.slide1.TabIndex = 3;
            // 
            // meterRPM
            // 
            this.meterRPM.Caption = "rpm";
            this.meterRPM.CaptionBackColor = System.Drawing.SystemColors.AppWorkspace;
            this.meterRPM.CaptionPosition = NationalInstruments.UI.CaptionPosition.Bottom;
            this.meterRPM.CoercionInterval = 10D;
            this.meterRPM.DialColor = System.Drawing.SystemColors.AppWorkspace;
            this.meterRPM.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.meterRPM.Location = new System.Drawing.Point(2, 17);
            this.meterRPM.Name = "meterRPM";
            this.meterRPM.Range = new NationalInstruments.UI.Range(0D, 6000D);
            this.meterRPM.Size = new System.Drawing.Size(347, 165);
            this.meterRPM.TabIndex = 2;
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.groupBox9.Controls.Add(this.label31);
            this.groupBox9.Controls.Add(this.label22);
            this.groupBox9.Controls.Add(this.thermometerCompressorTB);
            this.groupBox9.Controls.Add(this.textBoxCompressorLimit);
            this.groupBox9.Controls.Add(this.label12);
            this.groupBox9.Controls.Add(this.ledCompressor);
            this.groupBox9.Controls.Add(this.thermometerCompressor);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox9.Location = new System.Drawing.Point(314, 429);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(175, 309);
            this.groupBox9.TabIndex = 13;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Compressor";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(91, 252);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(45, 16);
            this.label31.TabIndex = 8;
            this.label31.Text = "degC";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(62, 46);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(36, 16);
            this.label22.TabIndex = 5;
            this.label22.Text = "Max";
            // 
            // thermometerCompressorTB
            // 
            this.thermometerCompressorTB.BackColor = System.Drawing.SystemColors.MenuBar;
            this.thermometerCompressorTB.Location = new System.Drawing.Point(69, 271);
            this.thermometerCompressorTB.Name = "thermometerCompressorTB";
            this.thermometerCompressorTB.ReadOnly = true;
            this.thermometerCompressorTB.Size = new System.Drawing.Size(90, 22);
            this.thermometerCompressorTB.TabIndex = 4;
            this.thermometerCompressorTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxCompressorLimit
            // 
            this.textBoxCompressorLimit.Location = new System.Drawing.Point(99, 42);
            this.textBoxCompressorLimit.Name = "textBoxCompressorLimit";
            this.textBoxCompressorLimit.Size = new System.Drawing.Size(67, 22);
            this.textBoxCompressorLimit.TabIndex = 3;
            this.textBoxCompressorLimit.Text = "91,3";
            this.textBoxCompressorLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(96, 24);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 16);
            this.label12.TabIndex = 2;
            this.label12.Text = "Limit";
            // 
            // ledCompressor
            // 
            this.ledCompressor.LedStyle = NationalInstruments.UI.LedStyle.Round3D;
            this.ledCompressor.Location = new System.Drawing.Point(99, 67);
            this.ledCompressor.Name = "ledCompressor";
            this.ledCompressor.OffColor = System.Drawing.Color.Gray;
            this.ledCompressor.OnColor = System.Drawing.Color.Red;
            this.ledCompressor.Size = new System.Drawing.Size(64, 64);
            this.ledCompressor.TabIndex = 1;
            // 
            // thermometerCompressor
            // 
            this.thermometerCompressor.Location = new System.Drawing.Point(0, 11);
            this.thermometerCompressor.Name = "thermometerCompressor";
            this.thermometerCompressor.Range = new NationalInstruments.UI.Range(0D, 125D);
            this.thermometerCompressor.Size = new System.Drawing.Size(101, 295);
            this.thermometerCompressor.TabIndex = 0;
            // 
            // thermometerHotbox
            // 
            this.thermometerHotbox.Location = new System.Drawing.Point(6, 13);
            this.thermometerHotbox.Name = "thermometerHotbox";
            this.thermometerHotbox.Range = new NationalInstruments.UI.Range(0D, 125D);
            this.thermometerHotbox.Size = new System.Drawing.Size(113, 188);
            this.thermometerHotbox.TabIndex = 0;
            // 
            // ledHotbox
            // 
            this.ledHotbox.LedStyle = NationalInstruments.UI.LedStyle.Round3D;
            this.ledHotbox.Location = new System.Drawing.Point(116, 47);
            this.ledHotbox.Name = "ledHotbox";
            this.ledHotbox.OffColor = System.Drawing.Color.Gray;
            this.ledHotbox.Size = new System.Drawing.Size(64, 64);
            this.ledHotbox.TabIndex = 1;
            // 
            // textBoxHBmax
            // 
            this.textBoxHBmax.Location = new System.Drawing.Point(115, 21);
            this.textBoxHBmax.Name = "textBoxHBmax";
            this.textBoxHBmax.Size = new System.Drawing.Size(64, 22);
            this.textBoxHBmax.TabIndex = 2;
            this.textBoxHBmax.Text = "105";
            this.textBoxHBmax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxHBmin
            // 
            this.textBoxHBmin.Location = new System.Drawing.Point(115, 110);
            this.textBoxHBmin.Name = "textBoxHBmin";
            this.textBoxHBmin.Size = new System.Drawing.Size(64, 22);
            this.textBoxHBmin.TabIndex = 3;
            this.textBoxHBmin.Text = "101";
            this.textBoxHBmin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // thermometerHotboxTB
            // 
            this.thermometerHotboxTB.BackColor = System.Drawing.SystemColors.MenuBar;
            this.thermometerHotboxTB.Location = new System.Drawing.Point(91, 165);
            this.thermometerHotboxTB.Name = "thermometerHotboxTB";
            this.thermometerHotboxTB.ReadOnly = true;
            this.thermometerHotboxTB.Size = new System.Drawing.Size(79, 22);
            this.thermometerHotboxTB.TabIndex = 4;
            this.thermometerHotboxTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.groupBox10.Controls.Add(this.label38);
            this.groupBox10.Controls.Add(this.label24);
            this.groupBox10.Controls.Add(this.label23);
            this.groupBox10.Controls.Add(this.thermometerHotboxTB);
            this.groupBox10.Controls.Add(this.textBoxHBmin);
            this.groupBox10.Controls.Add(this.textBoxHBmax);
            this.groupBox10.Controls.Add(this.ledHotbox);
            this.groupBox10.Controls.Add(this.thermometerHotbox);
            this.groupBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox10.Location = new System.Drawing.Point(805, 428);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(188, 200);
            this.groupBox10.TabIndex = 15;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Hotbox";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(78, 114);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(32, 16);
            this.label24.TabIndex = 7;
            this.label24.Text = "Min";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(78, 24);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(36, 16);
            this.label23.TabIndex = 6;
            this.label23.Text = "Max";
            // 
            // buttonDisconnect
            // 
            this.buttonDisconnect.Location = new System.Drawing.Point(9, 684);
            this.buttonDisconnect.Name = "buttonDisconnect";
            this.buttonDisconnect.Size = new System.Drawing.Size(118, 54);
            this.buttonDisconnect.TabIndex = 17;
            this.buttonDisconnect.Text = "Close connection";
            this.buttonDisconnect.UseVisualStyleBackColor = true;
            this.buttonDisconnect.Visible = false;
            this.buttonDisconnect.Click += new System.EventHandler(this.button2_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(260, 125);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(21, 16);
            this.label37.TabIndex = 13;
            this.label37.Text = "%";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(104, 141);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(45, 16);
            this.label38.TabIndex = 12;
            this.label38.Text = "degC";
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(1390, 768);
            this.Controls.Add(this.buttonDisconnect);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuMain;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1400, 800);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1400, 800);
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tester VFS169";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormMain_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuMain.ResumeLayout(false);
            this.menuMain.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ledStoper)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.thermometerDischarge)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gaugeDischarge)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.thermometerSuction)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gaugeSuction)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.thermometerCondOut)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thermometerCondIn)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ledCoil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.meterCoilCurrent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.meterCoilVoltage)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.slide1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.meterRPM)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ledCompressor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thermometerCompressor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thermometerHotbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ledHotbox)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuMain;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripMenuItem programSetupToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox StripCOM;
        private System.Windows.Forms.ToolStripComboBox StripBaud;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem testDescriptioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem startNewTestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem finishTestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setupToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem testParametersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem temperaturesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.IO.Ports.SerialPort COM;
        private System.Windows.Forms.Timer timerCOM;
        private System.Windows.Forms.ToolStripMenuItem commentsToTestToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.Timer timerStoper;
        private System.Windows.Forms.ToolStripMenuItem StripConnect;
        private System.Windows.Forms.ToolStripStatusLabel StripStatusCOM;
        private System.Windows.Forms.ToolStripProgressBar StripProgressCOM;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label labelStoper;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.ToolStripStatusLabel StripStatusData;
        private System.Windows.Forms.ToolStripStatusLabel StripStatusDane;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox9;
        private NationalInstruments.UI.WindowsForms.Thermometer thermometerCompressor;
        private NationalInstruments.UI.WindowsForms.Thermometer thermometerDischarge;
        private NationalInstruments.UI.WindowsForms.Gauge gaugeDischarge;
        private NationalInstruments.UI.WindowsForms.Gauge gaugeSuction;
        private NationalInstruments.UI.WindowsForms.Thermometer thermometerSuction;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox thermometerDischargeTB;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox thermometerSuctionTB;
        private System.Windows.Forms.TextBox thermometerCondOutTB;
        private System.Windows.Forms.TextBox thermometerCondInTB;
        private NationalInstruments.UI.WindowsForms.Thermometer thermometerCondOut;
        private NationalInstruments.UI.WindowsForms.Thermometer thermometerCondIn;
        private NationalInstruments.UI.WindowsForms.Meter meterRPM;
        private NationalInstruments.UI.WindowsForms.Slide slide1;
        private NationalInstruments.UI.WindowsForms.Led ledCompressor;
        private System.Windows.Forms.TextBox thermometerAirOutTB;
        private System.Windows.Forms.TextBox thermometerAirInTB;
        private System.Windows.Forms.TextBox thermometerEvapOutTB;
        private System.Windows.Forms.TextBox thermometerEvapInTB;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox thermometerCompressorTB;
        private System.Windows.Forms.TextBox textBoxCompressorLimit;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem pIDParametersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem graphsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aCLoopToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pressuresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem temperatureToolStripMenuItem;
        private NationalInstruments.UI.WindowsForms.Meter meterCoilCurrent;
        private NationalInstruments.UI.WindowsForms.Meter meterCoilVoltage;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBoxECVcurrent;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBoxECVvoltage;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBoxCoilCycles;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label gaugeDischargeLAB;
        private System.Windows.Forms.Label gaugeSuctionLAB;
        private NationalInstruments.UI.WindowsForms.Thermometer thermometerHotbox;
        private NationalInstruments.UI.WindowsForms.Led ledHotbox;
        private System.Windows.Forms.TextBox textBoxHBmax;
        private System.Windows.Forms.TextBox textBoxHBmin;
        private System.Windows.Forms.TextBox thermometerHotboxTB;
        private System.Windows.Forms.GroupBox groupBox10;
        private NationalInstruments.UI.WindowsForms.Led ledStoper;
        private System.Windows.Forms.ToolStripMenuItem splashScreenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem continueTestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveTestStatusToolStripMenuItem;
        private System.Windows.Forms.TextBox HumidityAirOutTB;
        private System.Windows.Forms.TextBox HumidityAirInTB;
        private System.Windows.Forms.Button buttonDisconnect;
        private NationalInstruments.UI.WindowsForms.Led ledCoil;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
    }
}

